<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Video Downloader</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
   

</head>
<body class="container py-5">
    <h1 class="text-center mb-4">Facebook/Instagram video Downloader</h1>
    <form action="/download" method="POST" class="w-50 mx-auto">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="video_url" class="form-label">Video URL</label>
            <div class="input-group">
            <input type="url" id="video_url" name="video_url" class="form-control" placeholder="Enter video URL" required>
            <button type="button" id="pasteButton" class="btn btn-primary">Paste</button>
            </div>
            <?php $__errorArgs = ['video_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button type="submit" class="btn btn-primary w-100">Download</button>
    </form>

    <script>
        document.getElementById('pasteButton').addEventListener('click', async function() {
            try {
                const text = await navigator.clipboard.readText();
                document.getElementById('video_url').value = text;
            } catch (err) {
                alert('Failed to read clipboard: ' + err.message);
            }
        });
    </script>
       
</body>
</html>
<?php /**PATH C:\Users\Admin\Desktop\videodownloader\video-downloader\resources\views/welcome.blade.php ENDPATH**/ ?>